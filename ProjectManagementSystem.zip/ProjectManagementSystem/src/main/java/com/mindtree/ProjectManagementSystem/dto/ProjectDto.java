package com.mindtree.ProjectManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ProjectDto {

	private int projectId;

	private String ProjectName;

	private String description;

	private int time;

	@JsonIgnoreProperties("project")
	private List<UserDto> users;

	public ProjectDto() {
		super();
	}

	public ProjectDto(int projectId, String projectName, String description, int time, List<UserDto> users) {
		super();
		this.projectId = projectId;
		ProjectName = projectName;
		this.description = description;
		this.time = time;
		this.users = users;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return ProjectName;
	}

	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public List<UserDto> getUsers() {
		return users;
	}

	public void setUsers(List<UserDto> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "ProjectDto [projectId=" + projectId + ", ProjectName=" + ProjectName + ", description=" + description
				+ ", time=" + time + ", users=" + users + "]";
	}

	

}
