package com.mindtree.ProjectManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.ProjectManagementSystem.dto.ProjectDto;
import com.mindtree.ProjectManagementSystem.dto.UserDto;

@Service
public interface UserProjectService {

	String LoginCheck(int userId, String password);

	ProjectDto InsertProjectsIntoDB(ProjectDto projectdto);

	List<ProjectDto> GetAllProjectsFromDB();

	UserDto InsertUsersIntoDB(UserDto userdto, int id);

	UserDto GetAllUsersById(int userId);

	String updatePassword(String newPassword, int userId);

	ProjectDto GetProjectFromDB(int userId);

	List<UserDto> getTeamMembersByUserIdFromDB(int userId);

}
