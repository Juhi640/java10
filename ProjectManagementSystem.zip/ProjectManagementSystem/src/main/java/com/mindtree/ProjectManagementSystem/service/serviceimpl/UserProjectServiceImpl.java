package com.mindtree.ProjectManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ProjectManagementSystem.dto.ProjectDto;
import com.mindtree.ProjectManagementSystem.dto.UserDto;
import com.mindtree.ProjectManagementSystem.entity.Project;
import com.mindtree.ProjectManagementSystem.entity.User;
import com.mindtree.ProjectManagementSystem.repository.ProjectRepository;
import com.mindtree.ProjectManagementSystem.repository.UserRepository;
import com.mindtree.ProjectManagementSystem.service.UserProjectService;

@Service
public class UserProjectServiceImpl implements UserProjectService{
	
	@Autowired
	UserRepository userrepository;

	@Autowired
	ProjectRepository projectrepository;
	
	@Override
	public String LoginCheck(int userId,String password) {
	String role="";
	List<User> users=new ArrayList<>();
	users=userrepository.findAll();
	for(User u:users) {
		if(u.getUserId()==userId) {
		if(u.getPassword().compareTo(password)==0) {
		role= u.getRole();	
		}
		}
	}
	return role;
	}
	
	@Override
	public ProjectDto InsertProjectsIntoDB(ProjectDto projectdto) {
	Project project=new Project();
	project.setProjectId(projectdto.getProjectId());
	project.setProjectName(projectdto.getProjectName());
	project.setDescription(projectdto.getDescription());
	project.setTime(projectdto.getTime());
	projectrepository.save(project);
	return projectdto;
	}
	
	@Override
	public List<ProjectDto> GetAllProjectsFromDB() {
	List<Project> projects=new ArrayList<>();
	projects=projectrepository.findAll();
	List<ProjectDto> projectdtos=new ArrayList<>();
	for(Project p:projects) {
	ProjectDto projectdto=new ProjectDto();
	projectdto.setProjectId(p.getProjectId());
	projectdto.setProjectName(p.getProjectName());
	projectdto.setDescription(p.getDescription());
	projectdto.setTime(p.getTime());
	projectdtos.add(projectdto);
	}
	return projectdtos;
	}
	
	
	@Override
	public UserDto InsertUsersIntoDB(UserDto userdto,int id) {
	User user=new User();
	Optional<Project> p = projectrepository.findById(id);
	Project project = p.get();
	user.setUserId(userdto.getUserId());
	user.setUserName(userdto.getUserName());
	user.setPassword(userdto.getPassword());
	user.setEmailId(userdto.getEmailId());
	user.setRole(userdto.getRole());
	//user.setDateOfJoining(userdto.getDateOfJoining());
	user.setProject(project);
	userrepository.save(user);
	return userdto;
	}
	
	@Override
	public UserDto GetAllUsersById(int userId){
		Optional<User> user=userrepository.findById(userId);
		User users=user.get();
		UserDto userdto=new UserDto();
		userdto.setUserId(users.getUserId());
		userdto.setUserName(users.getUserName());
		userdto.setPassword(users.getPassword());
		userdto.setEmailId(users.getEmailId());
		//userdto.setDateOfJoining(users.getDateOfJoining());
		userdto.setRole(users.getRole());
		return userdto;
		}
	
	
	@Override
	public String updatePassword(String newPassword,int userId) {
	String password="";
	Optional<User> user=userrepository.findById(userId);
	User u=user.get();
	u.setPassword(newPassword);
	userrepository.save(u);
	return "passwordchanged";
	}
	
	@Override
	public ProjectDto GetProjectFromDB(int userId) {
		Optional<User> user=userrepository.findById(userId);
		User u=user.get();
		ProjectDto projectdto=new ProjectDto();
		Project project=u.getProject();
		projectdto.setProjectId(project.getProjectId());
		projectdto.setProjectName(project.getProjectName());
		projectdto.setDescription(project.getDescription());
		projectdto.setTime(project.getTime());
		return projectdto;	
	}
	
	@Override
	public List<UserDto> getTeamMembersByUserIdFromDB(int userId){
	Optional<User> users=userrepository.findById(userId);
	User user= users.get();
	int projectId=user.getProject().getProjectId();
	Optional<Project> projects=projectrepository.findById(projectId);
	Project project=projects.get();
	List<UserDto> userdtos=new ArrayList<>();
	for(User user1:project.getUsers()) {
	UserDto userdto=new UserDto();
	userdto.setUserId(user1.getUserId());
	userdto.setUserName(user1.getUserName());
	userdto.setPassword(user1.getPassword());
	userdto.setEmailId(user1.getEmailId());
	//userdto.setDateOfJoining(user1.getDateOfJoining());
	userdto.setRole(user1.getRole());
	userdtos.add(userdto);
	}
	return userdtos;
	
	}
	}
	



