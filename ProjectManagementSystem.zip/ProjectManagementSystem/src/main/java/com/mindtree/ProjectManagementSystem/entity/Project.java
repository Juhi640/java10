package com.mindtree.ProjectManagementSystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PROJECT")
public class Project {

	@Id
	@Column(name="PROJECT")
	private int projectId;

	@Column(name = "PROJECT_NAME")
	private String ProjectName;

	@Column(name = "PROJECT_DESCRIPTION")
	private String description;

	@Column(name = "TIME")
	private int time;

	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
	private List<User> users;

	public Project() {
		super();
	}

	public Project(int projectId, String projectName, String description, int time, List<User> users) {
		super();
		this.projectId = projectId;
		ProjectName = projectName;
		this.description = description;
		this.time = time;
		this.users = users;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return ProjectName;
	}

	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", ProjectName=" + ProjectName + ", description=" + description
				+ ", time=" + time + "]";
	}

	
}
