package com.mindtree.ProjectManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.ProjectManagementSystem.entity.Project;

@Repository
public interface ProjectRepository extends JpaRepositoryImplementation<Project, Integer>{

}
