package com.mindtree.ProjectManagementSystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.mindtree.ProjectManagementSystem.dto.ProjectDto;
import com.mindtree.ProjectManagementSystem.dto.UserDto;
import com.mindtree.ProjectManagementSystem.service.UserProjectService;

@Controller
@SessionAttributes("userId")
public class AppController {

	@Autowired
	UserProjectService userprojectservice;

	@RequestMapping("/")
	public String login() {
		return "login";
	}

	@PostMapping("/user")
	public String CheckLogin(@RequestParam int userId, String password, Model model) {
		model.addAttribute(userprojectservice.LoginCheck(userId, password));
		model.addAttribute("role", userprojectservice.LoginCheck(userId, password));
		return "homepage";
	}

	@RequestMapping("/addprojects")
	public String projects() {
		return "projects";
	}

	@PostMapping(value = "/projectsadd")
	public String FillForm(ProjectDto projectdto) {
		userprojectservice.InsertProjectsIntoDB(projectdto);
		return "projects";
	}

	@GetMapping("/displayprojects")
	public String GetAllProjects(Model model) {
		List<ProjectDto> projectdtos = new ArrayList<>();
		projectdtos = userprojectservice.GetAllProjectsFromDB();
		model.addAttribute("allprojects", projectdtos);
		return "display";
	}

	@RequestMapping("/useradd")
	public String users() {
		return "users";
	}

	@PostMapping(path = "/adduser")
	public String FillUserForm(@RequestParam int projectId, UserDto userdto, Model model) {
		userprojectservice.InsertUsersIntoDB(userdto, projectId);
		return "users";

	}
	
	@GetMapping("/viewuserbyid")
	public String FindUserById() {
		return "searchpage";
	}
	
	@RequestMapping("/viewuser")
	public String ViewUserById(@RequestParam int userId ,Model model) {
		UserDto userdto=new UserDto();
		userdto=userprojectservice.GetAllUsersById(userId);
		model.addAttribute("user", userdto);
		System.out.println(userdto);
		return "userbyid";
	}
	
	@GetMapping("/changepassword")
	public String changePassword() {
		return"changePassword";
	}
	
	@PostMapping("/changenewPassword/{userId}")
	public String updatePasswordByNewPassword(@RequestParam String newPassword,@PathVariable int userId) {
	String c=userprojectservice.updatePassword(newPassword, userId);
	return "PasswordChanged";
	}
	
	@RequestMapping("/Viewallprojects")
	public String getProjects(@RequestParam int userId,Model model) {
	ProjectDto projectdto=new ProjectDto();
	projectdto=userprojectservice.GetProjectFromDB(userId);
	model.addAttribute("projectdto",projectdto);
	return "viewprojects";
	}
	
	@GetMapping("/Viewallteammembers")
	public String getTeamMembers(@PathVariable int userId,Model model) {
		List<UserDto> userdtos=userprojectservice.getTeamMembersByUserIdFromDB(userId);
		model.addAttribute("userdtos",userdtos);
		return "viewteammembers";
	}
	}


