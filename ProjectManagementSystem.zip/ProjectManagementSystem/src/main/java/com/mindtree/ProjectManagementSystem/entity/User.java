package com.mindtree.ProjectManagementSystem.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "USER")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	@Column(name = "USER_NAME")
	private String userName;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "DOJ")
	private Date DateOfJoining;

	@Column(name = "EMAIL_ID")
	private String emailId;

	@Column(name = "ROLE")
	private String role;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Project project;

	public User() {
		super();
	}

	public User(int userId, String userName, String password, Date dateOfJoining, String emailId, String role,
			Project project) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		DateOfJoining = dateOfJoining;
		this.emailId = emailId;
		this.role = role;
		this.project = project;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDateOfJoining() {
		return DateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		DateOfJoining = dateOfJoining;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", password=" + password + ", DateOfJoining="
				+ DateOfJoining + ", emailId=" + emailId + ", role=" + role + ", project=" + project + "]";
	}

	
}
